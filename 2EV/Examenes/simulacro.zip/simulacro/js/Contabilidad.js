class Contabilidad {

    constructor() {
        this.tiendas = [];
    }

}