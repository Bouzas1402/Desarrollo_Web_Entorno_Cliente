describe("Gastos", function (){
    var gastos;

    beforeEach(function() {
        gastos = new Gastos();
    });



});